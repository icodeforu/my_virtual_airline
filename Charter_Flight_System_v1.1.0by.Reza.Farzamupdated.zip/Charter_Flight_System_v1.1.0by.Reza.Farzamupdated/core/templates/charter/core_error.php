<div id="contenttext" align="center">
<table border="0" width="100%" cellpadding="0" cellspacing="0" dir="ltr">
	<tr>
		<td dir="ltr" align="left" width="22">
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/lu_red.png" width="22" height="22"></td>
		<td dir="ltr" align="center" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont_red.png">
		<b><font face="Tahoma" size="2">&nbsp;</font></b></td>
		<td dir="ltr" align="right" width="22">
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/ru_red.png" width="22" height="22"></td>
	</tr>
	<tr>
		<td dir="ltr" align="left" width="22" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont_red.png">
		&nbsp;</td>
		<td align="center" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont_red.png">
		
		<p align="center" dir="ltr">

		<table border="0" width="70%" dir="ltr" cellpadding="2">
			<tr>
				<td width="16%">
		
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/error.png" width="54" height="53"></td>
				<td>
						<?php
						echo '<div id="error" class="'.$class.'"><b><font color="#FFFFFF" size="2" face="Tahoma">'.$message.'</font></b></div>';
						?>
				</td>
			</tr>
		</table>

		
		
		</td>
		<td dir="ltr" align="right" width="22" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont_red.png">
		&nbsp;</td>
	</tr>
	<tr>
		<td dir="ltr" align="left" width="22">
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/lb_red.png" width="22" height="22"></td>
		<td align="center" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont_red.png">
		<b><font face="Tahoma" size="2">&nbsp;</font></b></td>
		<td dir="ltr" align="right" width="22">
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/rb_red.png" width="22" height="22"></td>
	</tr>
</table>
</div>