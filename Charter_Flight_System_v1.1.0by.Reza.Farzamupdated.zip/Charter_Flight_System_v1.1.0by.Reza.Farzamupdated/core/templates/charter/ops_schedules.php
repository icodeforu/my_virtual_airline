﻿<div id="contenttext" align="center">
<table border="0" width="100%" cellpadding="0" cellspacing="0" dir="ltr">
	<tr>
		<td dir="ltr" align="left" width="22">
		<img border="0" src="http://ifly-va.com/lib/images/charter/lu.png" width="22" height="22"></td>
		<td dir="ltr" align="center" background="http://ifly-va.com/lib/images/charter/bg_cont.png">
		<b><font face="Tahoma" size="2">&nbsp;</font></b></td>
		<td dir="ltr" align="right" width="22">
		<img border="0" src="http://ifly-va.com/lib/images/charter/ru.png" width="22" height="22"></td>
	</tr>
	<tr>
		<td dir="ltr" align="left" width="22" background="http://ifly-va.com/lib/images/charter/bg_cont.png">
		&nbsp;</td>
		<td align="center" background="http://ifly-va.com/lib/images/charter/bg_cont.png">
		
		<img src="http://ifly-va.com/lib/images/charter/charter_banner.png" border="0" width="767" height="62">
		
		
		<?php
		if(!Auth::LoggedIn())
		{
		?>		



		<p>
		&nbsp;</p>
		<p>
		<img border="0" src="http://ifly-va.com/lib/images/charter/error.png"></p>
		<p>
		&nbsp;</p>
<p>
		<b><font face="Tahoma" color="#FFFF00">Error<span lang="fa"> !!</span></font></b></p>
<p>
		<b><font face="Tahoma" color="#FFFFFF">You should Log-IN to access this 
		page <span lang="fa">!<br>
		&nbsp;</span></font></b></p>
		<p><font face="Tahoma" color="#FFFF00">
		<span style="font-size: 9pt; font-weight: 700">
		<a href="<?php echo SITE_URL?>/index.php"><font color="#FFFF00">
		<span style="text-decoration: none"><img border="0" src="http://ifly-va.com/lib/images/charter/return.png"></span></font></a> 
		</span></font></p>
		<p>
		
		
		
		<?php
		}
		elseif(Auth::LoggedIn())
		{
		?>

<?php
if ((Auth::$userinfo->totalhours + Auth::$userinfo->transferhours)>142)
{
?>

		<p align="center">
		
		<br>
		
					<?php
					$icao = 'CH';
					$price = Auth::$userinfo->pilotid;
					$count = SchedulesData::countCharterSchedules($icao, $price);
					if($count == 0)
					{
					?>
<br>
<br>
<br>
<br>
				<b><font face="Tahoma" style="font-size: 9pt" color="#00FFFF">
		You have not added any flight to your charter list !</font></b><br>
<br>
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a>
<br>
<br>
<br>
					<?php
					}
					else
					{
					?>

								<table width="100%" cellspacing="0" cellpadding="0" border="0" dir="ltr">
								<thead>
								<tr style="height:12px; font-size:14px; font-weight:normal">
								    <th align="center" colspan="10">
									<p align="left">
									<img border="0" src="http://ifly-va.com/lib/images/charter/charter_inner_bids.png" align="left"></th>
								</tr>
								<tr style="height:12px; font-size:14px; font-weight:normal">
								    <th colspan="10" bgcolor="#141863" dir="ltr">
											<p dir="ltr">
											<?php
											$bids = SchedulesData::getBids(Auth::$userinfo->pilotid);
											if(!$bids)
											{
											?>
												<br>
														<font face="Tahoma" style="font-size: 9pt" color="#95FF95">
											You have not any bided flight.</font><br>
												<br>												
											<?php	
											}
											else
											{
											?>
												<br>
													<font face="Tahoma" style="font-size: 9pt" color="#FF8C8C">
											You have a bided flight. </font><a href="<?php echo SITE_URL?>/index.php/schedules/bids">
											<font face="Tahoma" style="font-size: 9pt; text-decoration:none" color="#FFFF00">
											(view or delete)</font></a><br>
												<br>												
											<?php
											}
											?>	
									</th>
								</tr>
								<tr style="height:12px; font-size:14px; font-weight:normal">
								    <th align="center" colspan="10">
									&nbsp;</th>
								</tr>
								<tr style="height:12px; font-size:14px; font-weight:normal">
								    <th align="center" colspan="10">
									<img border="0" src="http://ifly-va.com/lib/images/charter/charter_inner_list.png"></th>
								</tr>
								</thead>
								<tbody>
				<?php
				$schedules = SchedulesData::findSchedules($params, $count = '', $start = '');
				foreach($schedules as $route)
				{
				if($route->price == Auth::$userinfo->pilotid && $route->code == 'CH')
				{
					if(Config::Get('DISABLE_SCHED_ON_BID') == true && $route->bidid != 0)
					{
						continue;
					}
				?>

<tr style="height:12px; font-size:14px; font-weight:normal;">
	<td align="center" bgcolor="#141863" width="5%"><i>
	<font size="2" color="#00FFFF">Charter</font></i></td>
	<td align="center" bgcolor="#141863" width="8%">
	<font color="#ffffff" style="font-size: 9pt" face="Tahoma"><?php echo $route->code . $route->flightnum?></font></td>
	<td align="center" valign="middle" bgcolor="#141863">
	<font color="#ffffff" style="font-size: 9pt" face="Tahoma"><?php echo $route->depname;?> 
	(<?php echo $route->depicao;?>)</font></td>
	<td align="center" valign="middle" bgcolor="#141863">
	<font color="#ffffff" style="font-size: 9pt" face="Tahoma"><?php echo $route->arrname;?> 
	(<?php echo $route->arricao;?>)</font></td>
	<td align="right" bgcolor="#141863" width="5%">
	<p align="center"><font color="#FFFF00" style="font-size: 9pt" face="Tahoma">&nbsp;&nbsp;&nbsp; 
	nM</font></td>
	<td align="left" bgcolor="#141863" width="7%">
	<font color="#ffffff" style="font-size: 9pt" face="Tahoma"><?php echo $route->distance;?></font></td>
	<td align="right" bgcolor="#141863" width="5%">
	<p align="center">
	<font color="#FFFF00" style="font-size: 9pt" face="Tahoma">&nbsp;&nbsp;&nbsp; 
	hr.</font></td>
	<td align="left" bgcolor="#141863" width="7%">
	<font color="#ffffff" style="font-size: 9pt" face="Tahoma"><?php echo $route->flighttime ;?></font></td>
	<td align="center" bgcolor="#141863" width="10%">
	<font color="#ffffff" style="font-size: 9pt" face="Tahoma"><?php echo $route->aircraft;?></font></td>
        <td align="center" bgcolor="#141863" width="18%"><font face="Tahoma">
		<span style="font-size: 9pt"><img title="Flight Brifing" onmouseover="document.body.style.cursor='pointer';" onmouseout="document.body.style.cursor='default';" class="{button:{icons:{primary:'ui-icon-arrowthick-1-s'}}}" href="#" onclick="$('#details_dialog_<?php echo $route->flightnum;?>').toggle()" src="http://ifly-va.com/lib/images/charter/Preview.png" border="0">
        
     
	   <?php 
		if($route->bidid != 0)
	    {
        ?>
	        <img title="Bid this Flight" src="http://ifly-va.com/lib/images/charter/ready.png" border="0">
        <?php
		}
        else
		{
		?>
		    <a id="<?php echo $route->id; ?>" class="addbid" href="<?php echo url('/schedules/addbid');?>">
		    <img title="Bid this Flight" src="http://ifly-va.com/lib/images/charter/bided.png" border="0"></a>
        <?php                    
        }
        ?>
	        	<a href="<?php echo SITE_URL?>/index.php/charter/editschedule?id=<?php echo $route->id?>"><img title="Edit this Flight" src="http://ifly-va.com/lib/images/charter/edit_icon.png" border="0"></a>
        </span></font>
        </td>
</tr>

        <td colspan="10">
		
		<table cellspacing="0" cellpadding="0" border="1" id="details_dialog_<?php echo $route->flightnum;?>" style="display:none" bgcolor="#ADDFFF" width="100%" dir="ltr">
		    
			<tr>
			<th align="center" bgcolor="#153E7E" colspan="4">
			<img src="http://ifly-va.com/lib/images/charter/4_fleet.png" border="0" height="18" width="18"><font style="font-size: 9pt;" color="white" face="Tahoma"> 
			Flight <span lang="en-us">Briefing</span></font></th>
			</tr>
			<tr>
			<td align="left" width="30%"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/3_flights.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;"> 
			Deaprture :</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b><font size="2"><?php echo "{$route->depname} ($route->depicao)"?></font></b></td>
			<td align="left" width="30%"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/3_flights.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;"> 
			Arrival<span lang="fa"> </span>:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b>
			<span style="font-size: 10pt"><?php echo "{$route->arrname} ($route->arricao)"?></span></b></td>
			</tr>
			<tr>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/4_fleet.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;"> 
			Aircraft :</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b><font size="2"><?php echo $route->aircraft; ?></font></b></td>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/1_today.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;">
			<span lang="en-us">Distance</span><span lang="fa"> </span>&nbsp;:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b>
			<span style="font-size: 10pt"><?php echo $route->distance . Config::Get('UNITS') ;?></span></b></td>
			</tr>
			<tr>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/5_time.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;"> 
			Departure Time<span lang="fa"> </span>:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b><font size="2"><?php echo $route->deptime?> 
			GMT</font></b></td>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/5_time.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;"> 
			Arrival Time<span lang="fa"> </span>:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b>
			<span style="font-size: 10pt"><?php echo $route->arrtime?> 
			GMT</span></b></td>
			</tr>
			<tr>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/1_today.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;">
			<span lang="en-us">Suggested</span> Altitude<span lang="fa"> </span>:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b><font size="2"><?php echo $route->flightlevel; ?> 
			ft</font></b></td>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/5_time.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;">
			<span lang="en-us">Duration</span> 
			:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b>
			<span style="font-size: 10pt"><?php echo $route->flighttime ;?></span></b></td>
			</tr>
			<tr>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/1_today.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;">
			<span lang="en-us">Days Operation</span><span lang="fa"> </span>:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b><font size="2"><?php echo Util::GetDaysCompact($route->daysofweek); ?></font></b></td>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/1_today.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;"> 
			F<span lang="en-us">are Price</span> 
			:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b> 
			<span style="font-size: 10pt">$4000</span></b></td>
			</tr>
			<tr>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/4_fleet.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;">
			<span lang="en-us">Flight Type</span> 
			:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b><font size="2">
			Charter Flight</font></b></td>
			<td align="left"><span style="font-size: 8pt;">
			<img src="http://ifly-va.com/lib/images/charter/6_pax.png" border="0" height="18" width="18"></span><font color="#ffffff" face="Tahoma"><span style="font-size: 8pt; font-weight: 700;">
			<span lang="en-us">Times Flown</span><span lang="fa"> </span>:</span></font></td>
			<td colspan="0" align="left" bgcolor="#ADDFFF"><b>
			<span style="font-size: 10pt"><?php echo $route->timesflown ;?></span></b></td>
			</tr>
						 </td>
			</tr>
			<tr>
			<th align="center" bgcolor="#153E7E" colspan="4"><font color="white">
			Flight Map</font></th>
			</tr>
			<tr>
			<td width="100%" colspan="4">
			<?php
			$string = "";
                        $string = $string.$route->depicao.'+-+'.$route->arricao.',+';
                        ?>

                        <img width="100%" src="http://www.gcmap.com/map?P=<?php echo $string ?>&amp;MS=bm&amp;MR=240&amp;MX=680x200&amp;PM=pemr:diamond7:red%2b%22%25I%22:red&amp;PC=%230000ff" />
									</tr>
									</td>
											 </table>	
									        </td>
									</tr>
									<?php
									 /* END OF ONE TABLE ROW */
									}
									}
									?>
	
								</tbody>
								</table>
								
								

<?php
}
?>
<?php
$icao = 'CH';
$price = Auth::$userinfo->pilotid;
$count = SchedulesData::countCharterSchedules($icao, $price);
if($count == 1)
{
?>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 1 charter 
						flight in your list and you have 29 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 2)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 2 charter 
						flight in your list and you have 28 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 3)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 3 charter 
						flight in your list and you have 27 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 4)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 4 charter 
						flight in your list and you have 26 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 5)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 5 charter 
						flight in your list and you have 25 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 6)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 6 charter 
						flight in your list and you have 24 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 7)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 7 charter 
						flight in your list and you have 23 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 8)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 8 charter 
						flight in your list and you have 22 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 9)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 9 charter 
						flight in your list and you have 21 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 10)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 10 charter 
						flight in your list and you have 20 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 11)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 11 charter 
						flight in your list and you have 19 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 12)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 12 charter 
						flight in your list and you have 18 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 13)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 13 charter 
						flight in your list and you have 17 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 14)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 14 charter 
						flight in your list and you have 16 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 15)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 15 charter 
						flight in your list and you have 15 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 16)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 16 charter 
						flight in your list and you have 14 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 17)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 17 charter 
						flight in your list and you have 13 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 18)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 18 charter 
						flight in your list and you have 12 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 19)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 19 charter 
						flight in your list and you have 11 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 20)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 20 charter 
						flight in your list and you have 10 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 21)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 21 charter 
						flight in your list and you have 9 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 22)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 22 charter 
						flight in your list and you have 8 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 23)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 23 charter 
						flight in your list and you have 7 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 24)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 24 charter 
						flight in your list and you have 6 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 25)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 25 charter 
						flight in your list and you have 5 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 26)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 26 charter 
						flight in your list and you have 4 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 27)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 27 charter 
						flight in your list and you have 3 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 28)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 28 charter 
						flight in your list and you have 2 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 29)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 29 charter 
						flight in your list and you have 1 charter flights to 
						add!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
				<td align="left" width="20%">
				<p align="center">
<a href="<?php echo SITE_URL?>/index.php/charter/addschedule">
				<img src="http://ifly-va.com/lib/images/charter/add_charter.png" border="0"></a></td>
			</tr>
		</table>
		<font color="#FFFF00">
<?php
}
elseif($count == 30)
{
?>
		</font>
		<table border="0" width="100%" dir="rtl">
			<tr>
				<td align="right">
				<div align="center">
				<table border="0" width="85%" dir="ltr">
					<tr>
						<td>
						<font style="font-size: 9pt;" face="Tahoma" color="#FFFF00">
						<b>
						<img src="http://ifly-va.com/lib/images/charter/count.png" border="0" height="24" width="29"></b></font></td>
						<td><b><font face="Tahoma" size="2" color="#FFFF00">You have 30 charter 
						flight in your list and you can NOT add any more charter 
						Flight!</font></b></td>
					</tr>
				</table>
				</div>
				</td>
			</tr>
		</table>
<?php
}
?>
<?php
}
elseif ((Auth::$userinfo->totalhours + Auth::$userinfo->transferhours)<142)
{
?>

				<table border="0" width="90%">
			<tr>
				<td dir="ltr">
				<p align="center">&nbsp;</p>
				<p align="center">&nbsp;</p>
				<p align="center"><b>
				<font color="#000080" size="2">
				<img border="0" src="http://ifly-va.com/lib/images/charter/error.png"></font></b></p>
				<p align="center"><b><font face="Tahoma" color="#FF5353">You do 
				not have permission to access this page</font><font face="Tahoma" color="#FF5353" size="3">!</font><font size="2" color="#000080" face="Tahoma"><span lang="fa"><br>
				</span></font><font face="Tahoma"><span lang="fa">
				<font color="#800000" size="2"><br>
				</font>
				</span><font size="2" color="#FFFF00">You should have at least 
				142 flight hours to access the Charter Flight System</font></font><span lang="fa"><font face="Tahoma" size="2" color="#FFFF00">!</font></span></b></p>
				</td>
			</tr>
			<tr>
				<td height="58" dir="ltr">
				<p align="center">&nbsp;<p align="center">
				<span style="font-size: 9pt; font-weight: 700">
				<font face="Tahoma" color="#A7BFDE">
				
		</font><font face="Tahoma" color="#FFFF00">
		<a href="<?php echo SITE_URL?>/index.php"><font color="#A7BFDE">
		<span style="text-decoration: none"><img border="0" src="http://ifly-va.com/lib/images/charter/return.png"></span></font></a></font><font face="Tahoma" color="#A7BFDE"> 
				</font></span><p align="center">&nbsp;<p align="center">&nbsp;<p align="center">
				&nbsp;</td>
			</tr>
			</table>

<?php
}
?>


<?php
}
?>		
		
		
		</td>
		<td dir="ltr" align="right" width="22" background="http://ifly-va.com/lib/images/charter/bg_cont.png">
		&nbsp;</td>
	</tr>
	<tr>
		<td dir="ltr" align="left" width="22">
		<img border="0" src="http://ifly-va.com/lib/images/charter/lb.png" width="22" height="22"></td>
		<td align="center" background="http://ifly-va.com/lib/images/charter/bg_cont.png">
		<b><font face="Tahoma" size="2">&nbsp;</font></b></td>
		<td dir="ltr" align="right" width="22">
		<img border="0" src="http://ifly-va.com/lib/images/charter/rb.png" width="22" height="22"></td>
	</tr>
</table>
</div>