﻿<div id="contenttext" align="center">
<table border="0" width="100%" cellpadding="0" cellspacing="0" dir="ltr">
	<tr>
		<td dir="ltr" align="left" width="22">
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/lu.png" width="22" height="22"></td>
		<td dir="ltr" align="center" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont.png">
		<b><font face="Tahoma" size="2">&nbsp;</font></b></td>
		<td dir="ltr" align="right" width="22">
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/ru.png" width="22" height="22"></td>
	</tr>
	<tr>
		<td dir="ltr" align="left" width="22" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont.png">
		&nbsp;</td>
		<td align="center" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont.png">
		
		<img src="<?php echo SITE_URL?>/lib/images/charter/charter_banner.png" border="0" width="767" height="62">
		
		
		<?php
		if(!Auth::LoggedIn())
		{
		?>		



		<p>
		&nbsp;</p>
		<p>
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/error.png"></p>
		<p>
		&nbsp;</p>
<p>
		<b><font face="Tahoma" color="#FFFF00">Error<span lang="fa"> !!</span></font></b></p>
<p>
		<b><font face="Tahoma" color="#000000">You should Log-IN to access this 
		page <span lang="fa">!<br>
		&nbsp;</span></font></b></p>
		<p><font face="Tahoma" color="#FFFF00">
		<span style="font-size: 9pt; font-weight: 700">
		<a href="<?php echo SITE_URL?>/index.php"><font color="#FFFF00">
		<span style="text-decoration: none"><img border="0" src="<?php echo SITE_URL?>/lib/images/charter/return.png"></span></font></a> 
		</span></font></p>
		<p>
		
		
		
		<?php
		}
		elseif(Auth::LoggedIn())
		{
		?>

<?php
if ((Auth::$userinfo->totalhours + Auth::$userinfo->transferhours)>142)
{
?>

<?php
$icao = 'CH';
$price = Auth::$userinfo->pilotid;
$count = SchedulesData::countCharterSchedules($icao, $price);
if($count < 30)
{
?>

					<p>&nbsp;</p>
					<br>
		
		
					<form action="<?php echo url('/Charter/schedules');?>" method="post">
					<table width="97%" class="tablesorter" dir="ltr" cellspacing="4" cellpadding="4">
					<tr>
						<td width="20%"><font face="Tahoma" color="#ffffff">
						<strong><span style="font-size: 9pt">Flight Type</span><span style="font-size: 9pt" lang="fa"> 
						:</span></strong></font></td>
						<td width="40%" align="left">
							<p dir="ltr">
							<span style="font-size: 9pt">
							<font color="#000000" face="Tahoma">
							<select name="code" style="font-weight: 700">
							<?php
							
							foreach($allairlines as $airline)
							{
								if($airline->code == "CH")
										{
											echo '<option value="'.$airline->code.'">'.$airline->name.'</option>';				    
										}
									else
										{
											continue;
										}
									}
									?>
							</select><b> </b>
						</font></span>
						</td>
						<td align="center" width="10%">
							<font face="Tahoma" color="#C0C0C0">
							<span style="font-size: 8pt" lang="fa">(</span><span style="font-size: 8pt">Non-Edit</span><span style="font-size: 8pt" lang="fa">)</span></font></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt">* This is a charter 
							flight.</span></font></td>
					</tr>
					<tr>
						<td><font face="Tahoma" color="#ffffff"><strong>
						<span style="font-size: 9pt">Your ID</span><span style="font-size: 9pt" lang="fa"> :</span></strong><span style="font-size: 9pt; font-weight:700">
						</span></font> </td>
						<td align="left">
							<p dir="ltr">
							<span style="font-size: 9pt">
							<font color="#00FFFF" face="Tahoma">
							<b><?php $pilotid = PilotData::GetPilotCode(Auth::$userinfo->code, Auth::$userinfo->pilotid); echo Auth::$userinfo->code; ?><?php $pilotid = PilotData::GetPilotCode(Auth::$userinfo->code, Auth::$userinfo->pilotid); echo Auth::$userinfo->pilotid; ?>
							</b>
							<input type="hidden" name="price" value="<?php $pilotid = PilotData::GetPilotCode(Auth::$userinfo->code, Auth::$userinfo->pilotid); echo Auth::$userinfo->pilotid; ?>" style="font-weight: 700" />
							</font></span>
						</td>
						<td align="center">
							<font face="Tahoma" color="#C0C0C0">
							<span style="font-size: 8pt" lang="fa">(</span><span style="font-size: 8pt">Non-Edit</span><span style="font-size: 8pt" lang="fa">)</span></font></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt" lang="fa">* </span></font>
							<font face="Tahoma" style="font-size: 8pt" color="#FFFF00">
							Check your ID.</font></td>
					</tr>
					<tr>
						<td><font face="Tahoma" color="#ffffff"><strong>
						<span style="font-size: 9pt">Flight Number</span><span style="font-size: 9pt" lang="fa"> :</span></strong></font></td>
						<td align="left">
							<p dir="ltr">
							<span style="font-size: 9pt">
							<font color="#000000" face="Tahoma">
							<input name="flightnum" value="<?php echo $schedule->flightnum;?>" size="20" minlength="5" maxlength="5" style="font-weight: 700" /><b>
							</b>
							</font></span>
						</td>
						<td align="center">
							<p dir="ltr">
							<font face="Tahoma" color="#FF5B5B">
							<span style="font-size: 8pt" lang="fa">
							(</span><span style="font-size: 8pt">*Required</span><span style="font-size: 8pt" lang="fa">)</span></font></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt" lang="fa">
							* </span>
							<span style="font-size: 8pt">
							You </span></font>
							<font face="Tahoma" style="font-size: 8pt" color="#FFFF00">
							must choose a number between 10001 and 12000 as your 
							charter flight number.</font></td>
					</tr>
					<tr>
						<td width="3%" nowrap>
						<font face="Tahoma" color="#ffffff"><strong>
						<span style="font-size: 9pt">Departure Airport</span><span style="font-size: 9pt" lang="fa"> :</span></strong></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input id="depicao" name="depicao" class="airport_select" value="<?php echo $schedule->depicao;?>" style="font-weight: 700" /><b>
						</b>
						</font></span>
						</td>
						<td align="center">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#FF5B5B">
							(</span><span style="font-size: 8pt">*Required</span><span style="font-size: 8pt" lang="fa">)</span></font></td>
						<td align="justify"><font face="Tahoma" color="#FFFF00">
						<span style="font-size: 8pt" lang="fa">* </span>
						<span style="font-size: 8pt">Enter your departure 
						airport (ex OIIE).</span></font></td>
					</tr>
					<tr>
						<td><font face="Tahoma" color="#ffffff"><strong>
						<span style="font-size: 9pt">Arrival Airport</span><span style="font-size: 9pt" lang="fa"> :</span></strong></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input id="arricao" name="arricao" class="airport_select" value="<?php echo $schedule->arricao;?>" style="font-weight: 700" /><b>
						</b>
						</font></span>
						</td>
						<td align="center">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#FF5B5B">
							(</font></span><font face="Tahoma" color="#FF5B5B"><span style="font-size: 8pt">*Required</span></font><span style="font-size: 8pt" lang="fa"><font face="Tahoma" color="#FF5B5B">)</font></span></td>
						<td align="justify"><font face="Tahoma" color="#FFFF00">
						<span style="font-size: 8pt" lang="fa">* </span>
						<span style="font-size: 8pt">Enter your arrival airport 
						(ex KJFK).</span></font></td>
					</tr>
					<tr>
						<td><font face="Tahoma" color="#ffffff">
						<span style="font-size: 9pt; font-weight:700">
						Departure Time</span><span style="font-size: 9pt; font-weight:700" lang="fa">
						:</span></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input name="deptime" value="<?php echo $schedule->deptime?>" style="font-weight: 700" /><b>
						</b>
							</font></span>
						</td>
						<td align="center">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#FF5B5B">
							(</font></span><font face="Tahoma" color="#FF5B5B"><span style="font-size: 8pt">*Required</span></font><span style="font-size: 8pt" lang="fa"><font face="Tahoma" color="#FF5B5B">)</font></span></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt" lang="fa">* </span>
							<span style="font-size: 8pt">Enter your estimated 
							departure time (ex 09:00).</span></font></td>
					</tr>
					<tr>
						<td><span style="font-weight: 700">
						<font face="Tahoma" style="font-size: 9pt" color="#ffffff">
						Arrival Time :</font></span><font face="Tahoma" color="#000000"><span style="font-size: 9pt; font-weight:700" lang="fa">
						</span></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input name="arrtime" value="<?php echo $schedule->arrtime?>" style="font-weight: 700" /><b>
						</b>
							</font></span>
						</td>
						<td align="center">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#FF5B5B">
							(</font></span><font face="Tahoma" color="#FF5B5B"><span style="font-size: 8pt">*Required</span></font><span style="font-size: 8pt" lang="fa"><font face="Tahoma" color="#FF5B5B">)</font></span></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt" lang="fa">* </span>
							<span style="font-size: 8pt">Enter your estimated 
							arrival time (ex 10:00).</span></font></td>
					</tr>
					<tr>
						<td><font face="Tahoma" color="#ffffff">
						<span style="font-size: 9pt; font-weight:700">
						Distance</span><span style="font-size: 9pt; font-weight:700" lang="fa">
						:</span></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input name="distance" id="distance" value="<?php echo $schedule->distance?>" style="font-weight: 700" /><b>
						</b>
							</font></span>
					</td>
						<td align="center">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#C0C0C0">
							(</span><span style="font-size: 8pt">Optional</span><span style="font-size: 8pt" lang="fa">)</span></font></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt" lang="fa">* </span>
							<span style="font-size: 8pt">Enter the distance as 
							nM (ex 219) or leave it blank.</span></font></td>
					</tr>
					<tr>
						<td><font face="Tahoma" color="#ffffff">
						<span style="font-size: 9pt; font-weight:700">
						Flight Time</span><span style="font-size: 9pt; font-weight:700" lang="fa">
						:</span></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input name="flighttime" value="<?php echo $schedule->flighttime?>" style="font-weight: 700" /><b>
						</b>
						</font></span>
						</td>
						<td align="center">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#C0C0C0">
							(</font></span><font face="Tahoma" color="#C0C0C0"><span style="font-size: 8pt">Optional</span></font><span style="font-size: 8pt" lang="fa"><font face="Tahoma" color="#C0C0C0">)</font></span></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt" lang="fa">* </span>
							<span style="font-size: 8pt">Enter the flight time 
							(ex 01:30) or leave it blank.</span></font></td>
					</tr>
					<tr>
						<td><font face="Tahoma" color="#ffffff"><strong>
						<span style="font-size: 9pt">Aircraft</span><span style="font-size: 9pt" lang="fa"> :</span></strong></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<select name="aircraft" style="font-weight: 700">
							<?php
							
							foreach($allaircraft as $aircraft)
							{
								if($aircraft->registration == $schedule->registration)
									$sel = 'selected';
								else
									$sel = '';
						
								echo '<option value="'.$aircraft->id.'" '.$sel.'>'.$aircraft->fullname.'</option>';
							}
							?>
							</select><b> </b>
						</font></span>
						</td>
						<td align="center">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#FF5B5B">
							(</font></span><font face="Tahoma" color="#FF5B5B"><span style="font-size: 8pt">*Required</span></font><span style="font-size: 8pt" lang="fa"><font face="Tahoma" color="#FF5B5B">)</font></span></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt">* Select your aircraft.</span></font></td>
					</tr>
					<tr>
						<td><font face="Tahoma" color="#ffffff"><strong>
						<span style="font-size: 9pt">Cruise Alt</span><span style="font-size: 9pt" lang="fa"> :</span></strong></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input name="flightlevel" value="<?php echo $schedule->flightlevel?>" style="font-weight: 700" /><b>
						</b>
						</font></span>
						</td>
						<td align="center">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#C0C0C0">
							(</font></span><font face="Tahoma" color="#C0C0C0"><span style="font-size: 8pt">Optional</span></font><span style="font-size: 8pt" lang="fa"><font face="Tahoma" color="#C0C0C0">)</font></span></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt" lang="fa">* </span></font>
							<font face="Tahoma" style="font-size: 8pt" color="#FFFF00">
							Enter the cruise altitude as Feet (ex 30000) or 
							leave it blank.</font></td>
					</tr>
					<tr>
						<td valign="top"><strong>
						<font face="Tahoma" style="font-size: 9pt" color="#ffffff">
						Route :</font></strong><font face="Tahoma" color="#000000"><strong><span style="font-size: 9pt" lang="fa"></span></strong></font></td>
						<td align="left">
						<p dir="ltr"><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<textarea name="route" style="width: 100%; height: 75px; font-weight:700" id="route"><?php echo $schedule->route?></textarea><b>
						</b>
							</font></span>
							</td>
						<td align="center" valign="top">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#C0C0C0">
							(</font></span><font face="Tahoma" color="#C0C0C0"><span style="font-size: 8pt">Optional</span></font><span style="font-size: 8pt" lang="fa"><font face="Tahoma" color="#C0C0C0">)</font></span></td>
						<td align="justify" valign="top">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt">* Enter the route (ex </span></font><span lang="fa"><font face="Tahoma" style="font-size: 8pt" color="#FFFF00"> 
							SAV R654 ISN R659 KAVOT</font></span><font face="Tahoma" color="#FFFF00"><span style="font-size: 8pt">) 
							or leave it blank.</span></font></td>
					</tr>
					<tr>
						<td valign="top"><strong>
						<font face="Tahoma" style="font-size: 9pt" color="#ffffff">
						Comment :</font></strong><font face="Tahoma" color="#000000"><strong><span style="font-size: 9pt" lang="fa"></span></strong></font></td>
						<td style="padding-top: 0px" align="left">
							<p dir="ltr">
							<span style="font-size: 9pt">
							<font color="#000000" face="Tahoma">
							<textarea name="notes" style="width: 100%; height: 150px; font-weight:700"><?php echo $schedule->notes?></textarea></font></span></td>
						<td style="padding-top: 0px" align="center" valign="top">
							<span style="font-size: 8pt" lang="fa">
							<font face="Tahoma" color="#C0C0C0">
							(</font></span><font face="Tahoma" color="#C0C0C0"><span style="font-size: 8pt">Optional</span></font><span style="font-size: 8pt" lang="fa"><font face="Tahoma" color="#C0C0C0">)</font></span></td>
						<td style="padding-top: 0px" align="justify" valign="top">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt">* Enter your comment or 
							leave it blank.</span></font></td>
					</tr>
					<tr>
						<td><strong>
						<font face="Tahoma" style="font-size: 9pt" color="#ffffff">
						Flight Status :</font></strong><font face="Tahoma" color="#000000"><strong><span style="font-size: 9pt" lang="fa"></span></strong></font></td>
						<?php $checked = ($schedule->enabled==1 || !$schedule)?'CHECKED':''; ?>
						<td><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input type="checkbox" id="enabled" name="enabled" style="font-weight: 700" /></font></span><font face="Tahoma" color="#ffffff"><span style="font-size: 9pt; font-weight:700" lang="fa"> 
						</span><span style="font-size: 9pt; font-weight:700"> 
						Available</span></font></td>
						</td>
						<td align="center">
							<font face="Tahoma" color="#C0C0C0">
							<span style="font-size: 8pt" lang="fa">(</span><span style="font-size: 8pt">Check-Box</span><span style="font-size: 8pt" lang="fa">)</span></font></td>
						<td align="justify">
							<font face="Tahoma" color="#FFFF00">
							<span style="font-size: 8pt">* </span></font>
							<font face="Tahoma" style="font-size: 8pt" color="#FFFF00">
							Set the flight status.</font></td>
					</tr>
					<tr>
						<td></td>
						<td><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
						<input type="hidden" name="action" value="<?php echo $action?>" style="font-weight: 700" />
							<input type="hidden" name="id" value="<?php echo $schedule->id?>" style="font-weight: 700" />
							<input type="hidden" id="<?php echo $route->id; ?>" class="addbid" name="addbid" value="<?php echo $route->id?>" style="font-weight: 700" />
							</font></span><span style="font-size: 9pt">
						<font color="#000000" face="Tahoma">
								<input border="0" type="image" name="submit" value="<?php echo $title?>" src="<?php echo SITE_URL?>/lib/images/charter/add_charter_sch.png" >
						</font></span>
						</td>
						<td align="center">&nbsp;</td>
						<td align="justify">&nbsp;</td>
					</tr>
					</table>
					</form>
					
					
					<br>
					<a href="<?php echo SITE_URL?>/index.php/charter">
					<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/return.png">
					</a>
					<br>

<?php
}
elseif($count >= 30)
{
?>


				<table border="0" width="90%">
			<tr>
				<td dir="ltr">
				<p align="center">&nbsp;</p>
				<p align="center">&nbsp;</p>
				<p align="center"><b>
				<font color="#000080" size="2">
				<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/error.png"></font></b></p>
				<p align="center"><b><font face="Tahoma" color="#FF5353">You do 
				not have permission to access this page</font><font face="Tahoma" color="#FF5353" size="3">!</font><font size="2" color="#000080" face="Tahoma"><span lang="fa"><br>
				</span></font><font face="Tahoma"><span lang="fa">
				<font color="#800000" size="2"><br>
				</font>
				</span><font size="2" color="#FFFF00">You have 30 charter 
				flights in your charter list.<br>
				You <u>can Not</u> add more than 30 charter flights in your list</font></font><span lang="fa"><font face="Tahoma" size="2" color="#FFFF00">!</font></span></b></p>
				</td>
			</tr>
			<tr>
				<td height="58" dir="ltr">
				<p align="center">&nbsp;<p align="center">
				<span style="font-size: 9pt; font-weight: 700">
				<font face="Tahoma" color="#A7BFDE">
				
		</font><font face="Tahoma" color="#FFFF00">
		<a href="<?php echo SITE_URL?>/index.php/charter"><font color="#A7BFDE">
		<span style="text-decoration: none"><img border="0" src="<?php echo SITE_URL?>/lib/images/charter/return.png"></span></font></a></font><font face="Tahoma" color="#A7BFDE"> 
				</font></span><p align="center">&nbsp;<p align="center">&nbsp;<p align="center">
				&nbsp;</td>
			</tr>
			</table>


<?php
}
?>
<?php
}
elseif ((Auth::$userinfo->totalhours + Auth::$userinfo->transferhours)<142)
{
?>

				<table border="0" width="90%">
			<tr>
				<td dir="ltr">
				<p align="center">&nbsp;</p>
				<p align="center">&nbsp;</p>
				<p align="center"><b>
				<font color="#000080" size="2">
				<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/error.png"></font></b></p>
				<p align="center"><b><font face="Tahoma" color="#FF5353">You do 
				not have permission to access this page</font><font face="Tahoma" color="#FF5353" size="3">!</font><font size="2" color="#000080" face="Tahoma"><span lang="fa"><br>
				</span></font><font face="Tahoma"><span lang="fa">
				<font color="#800000" size="2"><br>
				</font>
				</span><font size="2" color="#FFFF00">You should have at least 
				142 flight hours to access the Charter Flight System</font></font><span lang="fa"><font face="Tahoma" size="2" color="#FFFF00">!</font></span></b></p>
				</td>
			</tr>
			<tr>
				<td height="58" dir="ltr">
				<p align="center">&nbsp;<p align="center">
				<span style="font-size: 9pt; font-weight: 700">
				<font face="Tahoma" color="#A7BFDE">
				
		</font><font face="Tahoma" color="#FFFF00">
		<a href="<?php echo SITE_URL?>/index.php"><font color="#A7BFDE">
		<span style="text-decoration: none"><img border="0" src="<?php echo SITE_URL?>/lib/images/charter/return.png"></span></font></a></font><font face="Tahoma" color="#A7BFDE"> 
				</font></span><p align="center">&nbsp;<p align="center">&nbsp;<p align="center">
				&nbsp;</td>
			</tr>
			</table>

<?php
}
?>


<?php
}
?>		
		
		
		</td>
		<td dir="ltr" align="right" width="22" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont.png">
		&nbsp;</td>
	</tr>
	<tr>
		<td dir="ltr" align="left" width="22">
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/lb.png" width="22" height="22"></td>
		<td align="center" background="<?php echo SITE_URL?>/lib/images/charter/bg_cont.png">
		<b><font face="Tahoma" size="2">&nbsp;</font></b></td>
		<td dir="ltr" align="right" width="22">
		<img border="0" src="<?php echo SITE_URL?>/lib/images/charter/rb.png" width="22" height="22"></td>
	</tr>
</table>
</div>